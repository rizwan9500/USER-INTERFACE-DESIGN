select department_name
from department
where department_block_number = 3
order by department_name;